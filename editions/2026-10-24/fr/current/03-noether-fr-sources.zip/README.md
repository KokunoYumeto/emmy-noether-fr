# Emmy Noether — Sources françaises

Articles 1–43, cours de 1929/30 rédigé par M. Deuring, article de Kapferer et Noether et complément, bibliographie et listes terminales.

Le fichier [02-noether-fr.tex](02-noether-fr.tex) contient le texte cumulatif. Les fichiers modulaires sont conservés dans `source/`. Les notes critiques de cette variante, lorsqu’elles sont présentes, sont incluses dans le texte cumulatif et fournies séparément.

Compiler deux fois à la racine avec `xelatex -interaction=nonstopmode -halt-on-error 02-noether-fr.tex`. Une distribution TeX avec Babel français, les paquets AMS, TikZ, hyperref, longtable et microtype est nécessaire.

[Provenance et droits](RIGHTS.md).

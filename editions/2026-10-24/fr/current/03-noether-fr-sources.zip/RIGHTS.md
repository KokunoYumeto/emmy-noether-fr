# Auteurs, provenance et droits

Les œuvres mathématiques sont d’Emmy Noether et des auteurs nommés dans chaque texte. Le cours de 1929/30 a été rédigé par M. Deuring; les travaux de Kapferer et Noether conservent leurs signatures. La traduction française est produite par IA. Les corrections et la composition de cette édition sont produites par OpenAI Codex — GPT-6 Astra, effort Ultra, et, pour celles des 26 et 27 octobre 2026, par Claude Opus 5.5 (Anthropic), qui a aussi aligné les formules sur le texte allemand lu sur les pages imprimées de Noether. Aucune traduction humaine ni relecture scientifique humaine n’est attribuée à l’éditeur.

Emmy Noether est morte en 1935 : ses écrits sont donc dans le domaine public dans l'Union européenne et partout où la durée de protection prend fin 70 ans après la mort de l'auteur. Aux États-Unis, ses articles publiés pour la première fois en 1931 ou plus tard restent protégés jusqu'à 95 ans après leur publication (les articles de 1931 deviennent libres le 1er janvier 2027). Dans la mesure où l'éditeur détient des droits sur la traduction, les corrections et la composition produites par IA, il les verse au domaine public sous [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/deed.fr). Les leçons rédigées par M. Deuring, le travail de H. Kapferer et les contributions des coauteurs nommés ne sont pas concernés par cette déclaration ; leurs droits restent à leurs auteurs ou à leurs ayants droit.

Les notices historiques sont conservées dans le dépôt et les éditions antérieures, avec leur portée propre. Elles ne constituent pas une autorisation générale sur les œuvres d’autrui.

## Éditions sources

- [Édition française ED0014/v051](https://doi.org/10.5281/zenodo.21921884).
- [Édition allemande ED0014/v051](https://doi.org/10.5281/zenodo.21908301).

Les références des publications originales, les signatures et les citations se trouvent dans les textes.

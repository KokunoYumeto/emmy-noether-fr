# Emmy Noether — Écrits mathématiques en français

Texte de base. Articles 1–43, cours *Algèbre des grandeurs hypercomplexes* de 1929/30 rédigé par M. Deuring, article de Kapferer et Noether et complément, bibliographie et listes terminales.

Le fichier `02-noether-fr.tex` contient l’intégralité du texte cumulatif de cette variante. Les fichiers modulaires sont également conservés dans `source/`. Les notes critiques de la variante avec émendations sont fournies dans le texte cumulatif et séparément.

## Composition

Exécuter `python build.py` à la racine de cette archive. Le script utilise deux passages de LuaLaTeX, sans exécution de commandes externes par TeX, et produit `01-noether-fr-texte-base.pdf`. Le lecteur fourni a été composé avec LuaHBTeX 1.25.7 (MiKTeX 26.5). Installer Babel français, fontspec, les familles Latin Modern, les paquets AMS, TikZ, hyperref, longtable et microtype ainsi que les dépendances déclarées dans le préambule. Le script fixe les paramètres de date employés pour la composition. La date de composition fixée dans le PDF n’est pas sa date de publication.

Le fichier LaTeX directement téléchargeable `02-noether-fr-texte-base.tex` contient les mêmes octets que `02-noether-fr.tex`. Il est autonome : aucun texte ou dessin du recueil n’est remplacé par une image de page.

Traduction produite par IA; modèle initial non établi par les éléments de provenance disponibles. Corrections et composition : OpenAI Codex — GPT-6 Astra, effort Ultra ; Claude Opus 5.5 (Anthropic), 26 octobre 2026 (formules alignées sur le texte allemand lu sur les pages imprimées de Noether). Les auteurs des œuvres et du cours sont conservés dans les textes.

[Provenance et droits](RIGHTS.md) · [Déclaration historique](NOTICE_HISTORIQUE.md).
